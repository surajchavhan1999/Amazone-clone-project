#include<stdio.h>
 int main(){
	    
	 for(int i=1;i<5;i++);{
	
	    printf("%d enter the value");
	}
	return 0;
}